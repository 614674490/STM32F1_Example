#ifndef __LED_H
#define __LED_H
#include "sys.h"

#define led PCout(13)
void LED_Init(void);

#endif

